$(document).ready(function() {

	setTimeout(function(){
		$('#loaded').addClass('loaded');
		$('#body').show();
		// $('h1').css('color','#222222');
	}, 0);

	// $('#loader-wrapper').css({visibility: 'hidden'})

});
